domReady(function(){
	var oHtml=document.getElementsByTagName('html')[0],
		oBody=document.body,
		clientWidth=document.documentElement.clientWidth||document.body.clientWidth,
		clientHeight=document.documentElement.clientHeight||document.body.clientHeight;
	var s=clientWidth/clientHeight;
	if(s>=0.77){
		oBody.style.width=Math.floor(0.77*clientHeight)+"px";
		clientWidth=Math.floor(0.77*clientHeight);
	}
	oHtml.style.fontSize=clientWidth/16+"px";
});
window.onload=function(){
	
};